<?php

/**
 * Copyright (c) 2017, Skalfa LLC
 * All rights reserved.
 *
 * ATTENTION: This commercial software is intended for use with Oxwall Free Community Software http://www.oxwall.com/
 * and is licensed under Oxwall Store Commercial License.
 *
 * Full text of this license can be found at http://developers.oxwall.com/store/oscl
 */

abstract class SKMOBILEAPP_CLASS_AbstractInAppPurchase
{
    //response
    const SUCCESS = 1;
    const FAILURE = 0;
    const CANCEL = -1;

    public function __construct()
    {

    }
}