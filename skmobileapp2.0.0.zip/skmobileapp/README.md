
[![Build Status](https://travis-ci.com/skalfa/skmobileapp.svg?token=QcrThkQnN1PcXrGfJptN&branch=master)](https://travis-ci.com/skalfa/skmobileapp)

# skmobileapp
