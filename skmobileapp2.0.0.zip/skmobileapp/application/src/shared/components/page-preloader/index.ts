import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
    selector: 'page-preloader',
    templateUrl: 'index.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})

export class PagePreloaderComponent {
}
