export interface IMessageAttachmentResponse {
    downloadUrl?: string;
    fileName?: string;
    fileSize?: string;
    type?: string;
}
