
export interface IServerEventsResponse {
    channel: string;
    data: any;
}

