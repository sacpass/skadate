export interface IBookmarkResponse {
    id: number,
    user?: number;
}
