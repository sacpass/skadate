export interface IGenderResponse {
    id: string|number;
    name: string
}
