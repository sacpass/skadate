export interface IDistanceResponse {
    distance: number;
    unit: string;
}
