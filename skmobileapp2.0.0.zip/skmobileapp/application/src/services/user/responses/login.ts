export interface ILoginResponse {
    success: boolean;
    error?: string;
    token?: string;
}
