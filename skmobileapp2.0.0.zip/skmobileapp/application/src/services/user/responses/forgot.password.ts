export interface IForgotPasswordResponse {
    success: boolean;
    message: string
}

export interface IForgotPasswordValidateResponse {
    valid: boolean;
}

