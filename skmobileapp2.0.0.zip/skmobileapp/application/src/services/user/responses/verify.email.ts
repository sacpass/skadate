export interface IVerifyEmailResponse {
    valid: boolean;
}

export interface IResendVerifyEmailResponse {
    success: boolean;
    message: string
}

