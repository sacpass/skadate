export interface IPhotoResponse {
    id: number;
    approved?: boolean;
    bigUrl?: string;
    url?: string;
    userId?: number;
}