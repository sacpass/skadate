export interface ICreditActionResponse {
    amount: number;
    title: string;
}
