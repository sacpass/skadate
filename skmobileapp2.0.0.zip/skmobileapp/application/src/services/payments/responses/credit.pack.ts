export interface ICreditPackResponse {
    id: number;
    credits?: number;
    price?: number;
    productId?: string;
    definedProductId?: string;
}
