export interface IBillingGatewayResponse {
    name: string;
    isRedirectable?: boolean
}
