export interface IPurchaseItemResponse {
    key: string;
    value: string;
}
