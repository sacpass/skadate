export interface IMembershipActionResponse {
    label: string;
    permissions?: Array<string>
}
