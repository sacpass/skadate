export interface ILoginResponse {
    isSuccess: boolean;
    token?: string;
    action?: string;
}
