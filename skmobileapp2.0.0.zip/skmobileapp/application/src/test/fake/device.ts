export class DeviceFake  {
    cordova = '';
    model = '';
    platform = '';
    uuid = '';
    version = '';
    manufacturer = '';
    isVirtual = false;
    serial = '';
}
