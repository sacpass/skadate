var fs = require('fs');
var fixtures = []; // list of needed fixtures

var appRouter = function (app) {
    // middleware (check the trailing slash)
    app.use(function(req, res, next) {
        if (req.path.substr(-1) != '/' && req.path.length > 1) {
            res.sendStatus(404)

            return;
        }

        next();
    });

    // middleware (set content type and parse fixtures)
    app.use(function (req, res, next) {
        res.header('Content-Type','application/json');
        fixtures = req.get('fixtures')
            ? req.get('fixtures').split(',')
            : [];

        next();
    });

    // configs
    app.get('/skmobileapp/api/configs/', function(req, res) {
        var fixture = readFixtureJsonFile('configs.json');

        // enable maintenance mode
        if (fixtures.includes('configs_maintenance')) {
            res.send(Object.assign({}, fixture, {
                maintenanceMode: true
            }));

            return;
        }

        // enable maintenance mode
        if (fixtures.includes('configs_require_avatar')) {
            res.send(Object.assign({}, fixture, {
                isAvatarRequired: true
            }));

            return;
        }

        // return the normal fixture
        res.send(fixture);
    });

    // langs
    app.get('/skmobileapp/api/i18n/:id/', function(req, res) {
        // return the normal fixture
        res.send(readFixtureJsonFile('i18n.json'));
    });

    // server events
    app.get('/skmobileapp/api/server-events/', function(req, res) {
        res.header('Content-Type','text/event-stream');
        res.send([]);
    });

    // server events for logged users
    app.get('/skmobileapp/api/server-events/user/:id/', function(req, res) {
        res.header('Content-Type','text/event-stream');
        res.send([]);
    });
 
    // login
    app.post('/skmobileapp/api/login/', function(req, res) {
        var fixture = readFixtureJsonFile('login.json');

        // failed login
        if (fixtures.includes('login_failed')) {
            res.send(Object.assign({}, fixture, {
                success: false,
                error: 'Error',
                token: ''
            }));

            return;
        }

        // return the normal fixture
        res.send(fixture);
    });

    // users
    app.get('/skmobileapp/api/users/:id/', function(req, res) {
        var fixture = readFixtureJsonFile('user.json');

        // failed login
        if (fixtures.includes('user_with_avatar')) {
            res.send(Object.assign({}, fixture, {
                avatar: readFixtureJsonFile('avatar.json')
            }));

            return;
        }

        // return the normal fixture
        res.send(fixture);
    });

    // users location
    app.put('/skmobileapp/api/user-locations/me/', function(req, res) {
        // return the normal fixture
        res.send({});
    });

    // users devices
    app.post('/skmobileapp/api/devices/', function(req, res) {
        // return the normal fixture
        res.send({});
    });

    // forgot password (email)
    app.post('/skmobileapp/api/forgot-password/', function(req, res) {
        var fixture = readFixtureJsonFile('forgot.password.json');

        // failed login
        if (fixtures.includes('forgot_email_failed')) {
            res.send(Object.assign({}, fixture, {
                success: false,
                message: 'There is no user with this email address'
            }));

            return;
        }

        // return the normal fixture
        res.send(fixture);
    });

    // forgot password (new passwords)
    app.put('/skmobileapp/api/forgot-password/:code/', function(req, res) {
        var fixture = readFixtureJsonFile('forgot.password.json');

        // failed login
        if (fixtures.includes('forgot_password_failed')) {
            res.send(Object.assign({}, fixture, {
                success: false,
                message: 'Password is incorrect'
            }));

            return;
        }

        // return the normal fixture
        res.send(fixture);
    });

    // forgot password (validate code)
    app.post('/skmobileapp/api/validators/forgot-password-code/', function(req, res) {
        var fixture = readFixtureJsonFile('validator.json');

        // failed login
        if (fixtures.includes('forgot_code_failed')) {
            res.send(Object.assign({}, fixture, {
                valid: false
            }));

            return;
        }

        // return the normal fixture
        res.send(fixture);
    });

    // gender list
    app.get('/skmobileapp/api/user-genders/', function(req, res) {
        // return the normal fixture
        res.send(readFixtureJsonFile('genders.json'));
    });

    // validate user name
    app.post('/skmobileapp/api/validators/user-name/', function(req, res) {
        var fixture = readFixtureJsonFile('validator.json');

        // wrong user name
        if (fixtures.includes('validator_username_failed')) {
            res.send(Object.assign({}, fixture, {
                valid: false
            }));

            return;
        }

        // return the normal fixture
        res.send(fixture);
    });

    // validate email
    app.post('/skmobileapp/api/validators/user-email/', function(req, res) {
        var fixture = readFixtureJsonFile('validator.json');

        // wrong email
        if (fixtures.includes('validator_useremail_failed')) {
            res.send(Object.assign({}, fixture, {
                valid: false
            }));

            return;
        }

        // return the normal fixture
        res.send(fixture);
    });

    // upload avatars
    app.post('/skmobileapp/api/avatars/', function(req, res) {
        // return the normal fixture
        res.send(readFixtureJsonFile('join_avatar.json'));
    });

    // update avatar
    app.post('/skmobileapp/api/avatars/me/', function(req, res) {
        var fixture = readFixtureJsonFile('avatar.json');

        // wrong email
        if (fixtures.includes('avatar_upload_pending')) {
            res.send(Object.assign({}, fixture, {
                active: false
            }));

            return;
        }

        // return the normal fixture
        res.send(fixture);
    });

    // delete avatar
    app.delete('/skmobileapp/api/avatars/:id/', function(req, res) {
        // return the normal fixture
        res.status(204).send();
    });

    // join questions
    app.get('/skmobileapp/api/join-questions/:id/', function(req, res) {
        // return the normal fixture
        res.send(readFixtureJsonFile('join.questions.json'));
    });

    // autocomplete
    app.get('/skmobileapp/api/location-autocomplete/', function(req, res) {
        // return the normal fixture
        res.send(readFixtureJsonFile('location.autocomplete.json'));
    });

    // create user
    app.post('/skmobileapp/api/users/', function(req, res) {
        // return the normal fixture
        res.send(readFixtureJsonFile('user.json'));
    });

    // create questions data
    app.post('/skmobileapp/api/questions-data/', function(req, res) {
        // return the normal fixture
        res.send(readFixtureJsonFile('questions.data.json'));
    });

    // update questions data
    app.put('/skmobileapp/api/questions-data/me/', function(req, res) {
        // return the normal fixture
        res.send(readFixtureJsonFile('questions.data.json'));
    });

    // edit questions
    app.get('/skmobileapp/api/edit-questions/', function(req, res) {
        // return the normal fixture
        res.send(readFixtureJsonFile('edit.questions.json'));
    });
}

module.exports = appRouter;

/**
 * Read fixture json file
 */
function readFixtureJsonFile(fileName, encoding){
    if (typeof (encoding) == 'undefined'){
        encoding = 'utf8';
    }

    var file = fs.readFileSync(__dirname + '/fixtures/' + fileName, encoding);

    return JSON.parse(file);
}
