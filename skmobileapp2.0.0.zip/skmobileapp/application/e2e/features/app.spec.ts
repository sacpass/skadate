import { element, by } from 'protractor';
import { Utils, APPLICATION_CONFIG } from '../utils';
import {} from 'jasmine';

describe('App', () => {
    let utils: Utils;

    beforeEach(() => {
        utils = new Utils;
    });

    afterEach(() => {
        utils.cleanBrowser();
    });

    it('should have a title from the config file', async() => {
        await utils.reloadApp();

        expect(utils.getPageTitle()).toEqual(APPLICATION_CONFIG['name']);
    });

    it('maintenance mode page should be activated', async() => {
        await utils.reloadApp([
            'configs_maintenance'
        ]);

        const pageDesc = await element(by.css('h1')).getText();

        expect(pageDesc).toEqual('Under maintenance.');
    });
});
