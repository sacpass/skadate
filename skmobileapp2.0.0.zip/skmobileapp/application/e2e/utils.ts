import { browser, element, by, protractor } from 'protractor';
import { promise as webdriverPromise } from 'selenium-webdriver';

export const APPLICATION_CONFIG = require('../application.config.json');

export class Utils {
    authToken: string = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6MTkxMDYyLCJuYW1lIjoidGVzdGVyIiwiZW1haWwiOiJ0ZXN0ZXJAbWFpbC5jb20iLCJleHAiOjE2MzE1MjM3NjF9.NUw7G7N8AyVTFvjL64af_A4gUwlRgfbtDCfabKW2hlA';

    /**
     * Reload app
     */
    async reloadApp(fixtures: Array<string> = [], isUserLogged: boolean = false): Promise<any> {
        browser.ignoreSynchronization = false;

        const requestParams = '?fixtures=' + (fixtures.length ? fixtures.join(',') : '') + '&disable_push=true';

        await browser.get(requestParams);

        if (isUserLogged) {
            browser.executeScript("window.localStorage.setItem('token', '\"" + this.authToken + "\"')");

            await this.reloadApp(fixtures);
        }
 
        const waitAngular = browser.waitForAngular();

        waitAngular.then(() => {
            browser.ignoreSynchronization = true;
        });

        return waitAngular;
    }

    /**
     * Get page title
     */
    getPageTitle(): webdriverPromise.Promise<string> {
        return browser.getTitle();
    }

    /**
     * Clean browser
     */
    cleanBrowser(): void {
        browser.manage().deleteAllCookies();
        browser.executeScript('window.sessionStorage.clear();');
        browser.executeScript('window.localStorage.clear();');
    }

    /**
     * Fill google location box by id
     */
    async fillGoogleLocationBoxById(id, location: string, timeOut: number = 1000): Promise<any> {
        // show a select box
        await element.all(by.id(id)).first().element(by.tagName('input')).click();

        browser.sleep(timeOut);

        await this.fillInputByPlaceholder('Search', location);

        // wait for results
        await this.waitForElement('sk-autocomplete-result');

        // click a first item
        element(by.className('sk-autocomplete-results'))
            .all(by.className('sk-autocomplete-result')).get(0).click();

        return browser.sleep(timeOut);
    }

    /**
     * Fill date box by id
     */
    async fillDateBoxById(id, monthIndex: number, dayIndex: number, yearIndex: number, timeOut: number = 1000): Promise<any> {
        // show a select box
        await element.all(by.id(id)).first().element(by.tagName('button')).click();

        browser.sleep(timeOut);

        // select a month
        element(by.className('picker-columns'))
            .all(by.className('picker-col')).get(0)
            .all(by.className('picker-opt')).each(function(element, index) {
                if (index <= monthIndex) {
                    element.click();
                    browser.sleep(50);
                }
            });

        // select a day
        element(by.className('picker-columns'))
            .all(by.className('picker-col')).get(1)
            .all(by.className('picker-opt')).each(function(element, index) {
                if (index <= dayIndex) {
                    element.click();
                    browser.sleep(50);
                }
        });

        // select a year
        element(by.className('picker-columns'))
            .all(by.className('picker-col')).get(2)
            .all(by.className('picker-opt')).each(function(element, index) {
                if (index <= yearIndex) {
                    element.click();
                    browser.sleep(50);
                }
            });

        // click the 'ok' button
        element.all(by.className('picker-toolbar-button')).last().click(); 

        return browser.sleep(timeOut);
    }

    /**
     * Click action menu item
     */
    async clickActionMenuItem(actionIndex: number, timeOut: number = 1000): Promise<any> {
        // wait before the action menu is active
        await this.waitForElement('action-sheet-wrapper');

        // give a chance to finish all animations
        await browser.sleep(timeOut);

        await element(by.className('action-sheet-wrapper'))
            .all(by.className('action-sheet-button')).get(actionIndex).click();

        return  browser.sleep(timeOut);
    }

    /**
     * Fill select box by id
     */
    async fillSelectBoxById(id, selectedIndexes: Array<number>, timeOut: number = 1000): Promise<any> {
        // show a select box
        await element.all(by.id(id)).first().element(by.tagName('button')).click();

        browser.sleep(timeOut);

        // select a value
        element.all(by.className('alert-tappable')).each(function(element, index) {
            if (selectedIndexes.indexOf(index) != -1) {
                element.click();
            }
        });

        // click the 'ok' button
        element.all(by.className('alert-button')).last().click(); 

        return browser.sleep(timeOut);
    }

    /**
     * Upload file from static
     */
    async uploadFileFromStatic(fileName: string, uploaderCssClass, timeOut: number = 1000): Promise<any> {
        const path = require('path');
        const fileToUpload = '../e2e/server/static/' + fileName,
        absolutePath = path.resolve(__dirname, fileToUpload);

        await element(by.css('.' + uploaderCssClass + ' .sk-file-uploader-input')).sendKeys(absolutePath);

        return browser.sleep(timeOut);
    }

    /**
     * Click button
     */
    async clickButton(cssClass, timeOut: number = 1000): Promise<any> {
        await element(by.className(cssClass)).click();

        return browser.sleep(timeOut);
    }

    /**
     * Long tap
     */
    async longTap(cssClass, timeOut: number = 300): Promise<any> {
        await browser.actions().mouseDown(element(by.className(cssClass))).perform();
        await browser.sleep(timeOut);
        
        return browser.actions().mouseUp().perform();
    }

    /**
     * Fill input by placeholder
     */
    async fillInputByPlaceholder(placeholder: string, value: any): Promise<any> {
        const input = element(by.css('[placeholder="' + placeholder + '"]'));

        return input.sendKeys(value);
    }

    /**
     * Toaster
     */
    async toaster(): Promise<string> {
        await this.waitForElement('toast-message');

        return element(by.className('toast-message')).getText();
    }

    /**
     * Alert
     */
    async alert(): Promise<string> {
        await this.waitForElement('alert-sub-title');

        return browser.findElement(by.className('alert-sub-title')).getText();
    }

    /**
     * Confirm alert
     */
    async confirmAlert(timeOut = 1000): Promise<any> {
        await this.waitForElement('alert-button-group');

        // give a chance to finish all animations
        await browser.sleep(timeOut);

        return element(by.
            className('alert-button-group')).all(by.className('alert-button')).get(1).click();
    }

    /**
     * Wait for element
     */
    waitForElement(cssClass: string, timeOut: number = 5000): webdriverPromise.Promise<any>  {
        const EC = protractor.ExpectedConditions;

        return browser.wait(EC.presenceOf(element(by.className(cssClass))), timeOut);
    }

    /**
     * Wait for element is hidden
     */
    waitForElementHidden(cssClass: string, timeOut: number = 5000): webdriverPromise.Promise<any>  {
        const EC = protractor.ExpectedConditions;

        return browser.wait(EC.stalenessOf(element(by.className(cssClass))), timeOut);
    }

    /**
     * Wait for element attribute is hidden
     */
    waitForElementAttributeHidden(cssClass: string, attribute: string, timeOut: number = 5000): webdriverPromise.Promise<any>  {
        const EC = protractor.ExpectedConditions;

        return browser.wait(EC.stalenessOf(element(by.css('.' + cssClass + '[' + attribute + ']'))), timeOut);
    }

    /**
     * Wait for element attribute
     */
    waitForElementAttribute(cssClass: string, attribute: string, timeOut: number = 5000): webdriverPromise.Promise<any>  {
        const EC = protractor.ExpectedConditions;

        return browser.wait(EC.presenceOf(element(by.css('.' + cssClass + '[' + attribute + ']'))), timeOut);
    }
}
